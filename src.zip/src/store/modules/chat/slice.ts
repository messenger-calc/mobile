import { PayloadAction, createSlice } from "@reduxjs/toolkit";
import { TMessageInternal, TMessageUser } from "../../../common/types/chat";
import { RootState } from "../../store";

interface IChatState {
    chat: (TMessageUser | TMessageInternal)[];
    userNickname: string,
    otherUserNickname: string,
    userAppId: string;
    otherUserAppId: string;
}

const initialState: IChatState = {
    chat: [],
    userNickname: '',
    otherUserNickname: '',
    userAppId: '',
    otherUserAppId: '',
}

export const chatSlice = createSlice({
    name: 'chat',
    initialState,
    reducers: {
      addMessage: (state, action: PayloadAction<TMessageUser | TMessageInternal>) => {
        state.chat.push(action.payload); 
      },
      clearChat: (state) => {
        state.chat = [];
      },
      setUserNickname: (state, action: PayloadAction<string>) => {
        state.userNickname = action.payload;
      },
      setOtherUserNickname: (state, action: PayloadAction<string>) => {
        state.otherUserNickname = action.payload;
      },
      setUserAppId: (state, action: PayloadAction<string>) => {
        state.userAppId = action.payload;
      },
      setOtherUserAppId: (state, action: PayloadAction<string>) => {
        state.otherUserAppId = action.payload;
      }
    },
  })
  
  export const { addMessage, setOtherUserAppId, setUserAppId, setUserNickname, setOtherUserNickname, clearChat } = chatSlice.actions
  
  // Other code such as selectors can use the imported `RootState` type
  export const getChat = (state: RootState) => state.chat.chat;
  export const getUserNickname = (state: RootState) => state.chat.userNickname;
  export const getOtherUserNickname = (state: RootState) => state.chat.otherUserNickname;
  export const getUserAppId = (state: RootState) => state.chat.userAppId;
  export const getOtherUserAppId = (state: RootState) => state.chat.otherUserAppId;
  
  export default chatSlice.reducer;