import { PayloadAction, createSlice } from "@reduxjs/toolkit";
import { TMessageInternal, TMessageUser } from "../../../common/types/chat";
import { RootState } from "../../store";

interface ICallReducer {
  remoteSrc: any,
  localSrc: any,
  isCaller: boolean,
}

const initialState: ICallReducer = {
  remoteSrc: null,
  localSrc: null,
  isCaller: false,
}

export const callSlice = createSlice({
    name: 'callSlice',
    initialState,
    reducers: {
      setRemoteSrc: (state, action: PayloadAction<any>) => {
        console.log('Set RemoteSrc!');
        state.remoteSrc = action.payload;
      },
      setLocalSrc: (state, action: PayloadAction<any>) => {
        console.log('Set LocalSrc!');
        state.localSrc = action.payload;
      },
      setIsCaller: (state, action: PayloadAction<boolean>) => {
        console.log('Set isCaller state!');
        state.isCaller = action.payload;
      },
    },
  })
  
  export const { setRemoteSrc, setIsCaller, setLocalSrc } = callSlice.actions
  
  // Other code such as selectors can use the imported `RootState` type
  export const getCallRemoteSrc = (state: RootState) => state.call.remoteSrc;
  export const getCallLocalSrc = (state: RootState) => state.call.localSrc;
  export const getCallIsCaller = (state: RootState) => state.call.isCaller;
  
  export default callSlice.reducer;