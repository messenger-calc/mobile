import { PayloadAction, createSlice } from "@reduxjs/toolkit";
import { TMessageInternal, TMessageUser } from "../../../common/types/chat";
import { RootState } from "../../store";

export enum EAppState {
    Init = "Init",

    TryConnection = 'TryConnection',
    SuccessConnection = 'SuccessConnection',
    RejectConnection = 'RejectConnection',
    AskUserToConnect = 'AskUserToConnect',
    WaitOtherUserAnswer = 'WaitOtherUserAnswer',

    FinishConnection = 'FinishConnection',

    ButtonStartAudioCallPressed = 'ButtonStartAudioCallPressed',
    WaitingAnswerAudioCall = 'WaitingAnswerAudioCall',
    CallingAudioCall = 'CallingAudioCall',
    SuccessAudioCall = 'SuccessAudioCall',
    RejectAudioCall = 'RejectAudioCall',
}

interface IAppState {
    state: EAppState
}

const initialState: IAppState = {
    state: EAppState.Init,
}

export const appSlice = createSlice({
    name: 'appState',
    initialState,
    reducers: {
      setAppState: (state, action: PayloadAction<EAppState>) => {
        console.log('APP STATE CHANGED TO => ', action.payload)
        state.state = action.payload;
      },
    },
  })
  
  export const { setAppState } = appSlice.actions
  
  // Other code such as selectors can use the imported `RootState` type
  export const getAppState = (state: RootState) => state.appState;
  
  export default appSlice.reducer;