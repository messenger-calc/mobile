import { NavigationContainer } from "@react-navigation/native";
import React from "react";
import { MainStack } from "./stacks/Main";
import Contexts from "../common/contexts/Context";
import { Provider } from "react-redux";
import { store } from "../store/store";

export const Navigator = () => {
    return (
        <NavigationContainer>
            <Provider store={store}>
                <Contexts>
                    <MainStack />
                </Contexts>
            </Provider>
        </NavigationContainer>
    )
}