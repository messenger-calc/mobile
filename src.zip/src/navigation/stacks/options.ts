import { NativeStackNavigationOptions } from "@react-navigation/native-stack";

export const ScreenNavigationOptions: NativeStackNavigationOptions = {
  headerShown: false,
  // contentStyle: {
  //   backgroundColor: EColors.white,
  // },
}


export const ScreenCallNavigationOptions: NativeStackNavigationOptions = {
    headerShown: false,
    animation: 'none'
    // contentStyle: {
    //   backgroundColor: EColors.white,
    // },
  }
  