export enum EStacks {
    Home = 'HomeStack',
    Chat = 'ChatStack',
    Call = 'CallStack',
}