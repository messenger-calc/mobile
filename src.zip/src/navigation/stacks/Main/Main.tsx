import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { TMainStack } from './types';
import { ScreenNavigationOptions } from '../options';
import { CalculatorScreens } from '../../../screens/Calculator';
import { EScreens } from '../../screens';
import { EStacks } from '../stacks';
import { ChatStack } from '../Chat';
import Call from '../../../screens/Chat/Call/Call';

const Stack = createNativeStackNavigator<TMainStack>();

export const MainStack = () => {
    return (
        <Stack.Navigator screenOptions={ScreenNavigationOptions}>
            <Stack.Screen component={CalculatorScreens.Main} name={EScreens.CalculatorMain}/>
            <Stack.Screen component={ChatStack} name={EStacks.Chat}/>
            {/* <Stack.Screen component={CallStack} name={EStacks.Call}/> */}
            <Stack.Screen component={Call} name={EScreens.Call}/>
        </Stack.Navigator>
    );
}