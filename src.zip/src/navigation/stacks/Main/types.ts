import { EScreens } from "../../screens"
import { TNavigatorScreenParams } from "../../types"
import { TChatStack } from "../Chat"
import { EStacks } from "../stacks"

export type TMainStack = {
    [EStacks.Chat]: TNavigatorScreenParams<TChatStack>,
    // for Calculator
    [EScreens.CalculatorMain]: undefined
    [EStacks.Call]: undefined,
    [EScreens.Call]: undefined,
}