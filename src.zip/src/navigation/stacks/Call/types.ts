import { EScreens } from "../../screens"

export type TCallStack = {
    [EScreens.CallActive]: undefined,
    [EScreens.CallWaiting]: undefined,
    [EScreens.CallCalling]: undefined,
}