import React from 'react';
import { TCallStack } from './types';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { ScreenCallNavigationOptions } from '../options';
import { EScreens } from '../../screens';
import { ChatScreens } from '../../../screens/Chat';

const Stack = createNativeStackNavigator<TCallStack>();

const CallStack = () => {
    return (
        <Stack.Navigator screenOptions={ScreenCallNavigationOptions}>
            <Stack.Screen component={ChatScreens.Main} name={EScreens.CallWaiting}/>
            <Stack.Screen component={ChatScreens.ChatMessage} name={EScreens.CallCalling}/>
            <Stack.Screen component={ChatScreens.ChatMessage} name={EScreens.CallActive}/>
        </Stack.Navigator>
    );
};

export default CallStack;