import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { TChatStack } from './types';
import { ChatScreens } from '../../../screens/Chat';
import { EScreens } from '../../screens';
import { ScreenNavigationOptions } from '../options';

const Stack = createNativeStackNavigator<TChatStack>();

export const ChatStack = () => {
    return (
        <Stack.Navigator screenOptions={ScreenNavigationOptions}>
            <Stack.Screen component={ChatScreens.Main} name={EScreens.ChatMain}/>
            <Stack.Screen component={ChatScreens.ChatMessage} name={EScreens.ChatMessage}/>
        </Stack.Navigator>
    );
}