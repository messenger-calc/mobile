import { EScreens } from "../../screens"

export type TChatStack = {
    [EScreens.ChatMain]: undefined,
    [EScreens.ChatMessage]: undefined,
}