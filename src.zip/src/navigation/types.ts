import { NavigatorScreenParams, ParamListBase } from "@react-navigation/native";
import { TChatStack } from "./stacks/Chat";
import { TMainStack } from "./stacks/Main";

export type TScreens = TMainStack & 
TChatStack

export type TNavigatorScreenParams<
  TStack extends ParamListBase,
  TStackParams = undefined,
> = NavigatorScreenParams<TStack> | TStackParams