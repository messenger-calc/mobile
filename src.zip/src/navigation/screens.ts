export enum EScreens {
    CalculatorMain = 'CalculatorMain',
    
    ChatMessage = 'ChatMessage',
    ChatMain = 'ChatMain',

    CallCalling = 'CallCalling',
    CallWaiting = 'CallWaiting',
    CallActive = 'CallActive',

    Call = 'Call',
}