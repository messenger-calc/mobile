import React, { Ref, RefObject, createRef, useContext, useEffect, useRef, useState } from 'react';
import { Keyboard, NativeScrollEvent, NativeSyntheticEvent, SafeAreaView, ScrollView, StyleSheet, Text, TextInput, Vibration, View } from 'react-native';
import { ButtonIconBackward, ButtonIconCall, ButtonIconDisable, ButtonIconSend, Header, MainContainer, MessagesArea, RowContainer, StyledTextInput, TextInputArea, Title, Window } from './styles';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { Svg } from '../../../assets/icons';
import { useNavigation } from '@react-navigation/native';
import { ChatContext } from '../../../common/contexts/Chat/Chat';
import { Message } from './components/Message/Message';
import { EMessageType, TMessageUser } from '../../../common/types/chat';
import { v4 as uuidv4 } from 'uuid';
import { useAppDispatch, useAppSelector } from '../../../store/hooks';
import { EAppState, setAppState } from '../../../store/modules/appState/slice';
import socket from '../../../common/utils/socket';

export const ChatMessage = () => {
    const messageScrollViewRef = createRef<ScrollView>();

    const [isKeyboardVisible, setKeyboardVisible] = useState(false);
    const [isAtBottom, setIsAtBottom] = useState(false);

    const [newMessageText, setNewMessageText] = useState<string>('');
    // const beepEndSoundRef = useRef<Sound>(null!);

    const chatData = useAppSelector((store) => store.chat);
    const userNickname = useAppSelector((store) => store.chat.userNickname);
    const appDispatch = useAppDispatch();
    const { theme, chatStatus, setChatStatus, sendMessage } = useContext(ChatContext);
    const navigation = useNavigation();

    useEffect(() => {
        const keyboardDidShowListener = Keyboard.addListener(
          'keyboardDidShow',
          () => {
            setKeyboardVisible(true); // or some other action
          }
        );
        const keyboardDidHideListener = Keyboard.addListener(
          'keyboardDidHide',
          () => {
            setKeyboardVisible(false); // or some other action
          }
        );
    
        return () => {
          keyboardDidHideListener.remove();
          keyboardDidShowListener.remove();
        };
      }, []);

    useEffect(() => {
        Vibration.vibrate([0.3, 0.3]);
    }, []);

    // useEffect(() => {
    //     beepEndSoundRef.current = new Sound('end_beep.mp3', Sound.MAIN_BUNDLE, (err) => {
    //         if (err) {
    //             console.log('Failed to load the sound "end_beep.mp3". ', err);
    //         }

    //         beepEndSoundRef.current.setNumberOfLoops(1);
    //         beepEndSoundRef.current.setVolume(1);
    //         beepEndSoundRef.current.play((success) => {
    //             if (success) {
    //                 beepEndSoundRef.current.release();
    //             }
    //         })
    //     })
    // }, [])

    useEffect(() => {
        if (!isKeyboardVisible) {
            setNewMessageText('');
            messageScrollViewRef.current?.scrollToEnd({ animated: true });
        }
    }, [isKeyboardVisible]);

    // useEffect(() => {
    //     const lastElem = chatData.chat.length - 1;


    //     // if new message is sended by us
    //     if (chatData.chat[lastElem]?.type === EMessageType.User) {
    //         if ((chatData.chat[lastElem] as TMessageUser).from !== userNickname) {
    //             if (isAtBottom) {
    //                 messageScrollViewRef.current?.scrollToEnd({ animated: true });
    //             }
    //         } else {
    //             // if new other user message
    //             if (!isAtBottom) {
    //                 setShowDownScrollButton(true);
    //             }
    //         }
    //     }
    // }, [chatData.chat, isKeyboardVisible]);

    // useEffect(() => {
    //     if (isAtBottom) {
    //         setShowDownScrollButton(false);
    //     }
    // }, [isAtBottom])

    useEffect(() => {
        messageScrollViewRef.current?.scrollToEnd({ animated: true });
    }, [chatData.chat])

    const onHandleChange = (text: string) => {
        setNewMessageText(text);
    }

    const onHandleSend = () => {
        if (!newMessageText) {
            return;
        }

        setNewMessageText('');
        Keyboard.dismiss();
        setNewMessageText('');
        sendMessage({ 
            type: EMessageType.User,
            show: true,
            text: newMessageText,
            from: chatData.userNickname
        } as TMessageUser);

        messageScrollViewRef.current?.scrollToEnd({ animated: true });
    }

    const onHandleBackward = () => {
        navigation.goBack();
    }

    const handleScroll = (event: any) => {
        const { contentOffset, layoutMeasurement, contentSize } = event.nativeEvent;
    
        // Calculate the current position
        const currentPosition = contentOffset.y + layoutMeasurement.height;
    
        // Calculate the maximum position (content size)
        const maximumPosition = contentSize.height;
    
        // Check if the current position is near the bottom
        const isNearBottom = maximumPosition - currentPosition < 33;
    
        setIsAtBottom(isNearBottom);
    };

    return (
            <Window>
                <MainContainer>
                    <Header style={styles.headerBorderBottom}>
                        <View style={{ flexDirection: 'row', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                            <ButtonIconBackward onPress={onHandleBackward}>
                                <Svg.Backward fill={theme === 'light' ? '#000' : '#fff'}/>
                            </ButtonIconBackward>
                            <Title>{chatData.otherUserNickname}</Title>
                        </View>
                        {chatStatus && <Text style={{color: theme === 'light' ? '#fff' : '#000'}}>{chatStatus}</Text>}
                    </Header>

                
                    <KeyboardAwareScrollView 
                        scrollEnabled={false}
                        enableAutomaticScroll={true}
                        contentContainerStyle={{ flex: 1 }} 
                        keyboardOpeningTime={1}
                        extraHeight={200}
                        keyboardShouldPersistTaps="handled">
                        <MessagesArea 
                            ref={messageScrollViewRef}
                            scrollEventThrottle={16}
                            onScroll={handleScroll}>
                            {chatData.chat.map(message => {
                                if (message.type === EMessageType.Internal) {
                                    return;
                                }
                                return (
                                    <Message 
                                    key={uuidv4()} 
                                    messageData={message as TMessageUser} 
                                    nickname={chatData.userNickname}/>
                                )
                            })}
                        </MessagesArea>

                        
                            <SafeAreaView >
                                <TextInputArea>
                                    <RowContainer>
                                        <ButtonIconDisable
                                            onPress={() => {
                                                appDispatch(setAppState(EAppState.FinishConnection));
                                            }}>
                                            <Svg.PhoneDisable fill={'#fff'} width={13} height={13}/>
                                        </ButtonIconDisable>
                                        <ButtonIconCall onPress={() => {
                                            appDispatch(setAppState(EAppState.ButtonStartAudioCallPressed));
                                            setChatStatus('Дзвінок...');
                                        }}>
                                            <Svg.Phone 
                                            fill={theme === "light" ? '#000' : '#fff'} 
                                            width={13} 
                                            height={13}/>
                                        </ButtonIconCall>
                                        <StyledTextInput
                                            placeholder="SMS"
                                            placeholderTextColor={
                                                theme === "light" 
                                                ? 'rgba(0, 0, 0, 0.25)' 
                                                : 'rgba(255, 255, 255, 0.25)'
                                            }
                                            onChangeText={onHandleChange}
                                            multiline={true}
                                            value={newMessageText} />
                                        <View>
                                            <ButtonIconSend style={{...styles.verifyButton, borderRadius: 13}} onPress={onHandleSend}>
                                                <Svg.Send fill={'#000000'} />
                                            </ButtonIconSend>
                                        </View>
                                    </RowContainer>
                                </TextInputArea>
                            </SafeAreaView>
                    </KeyboardAwareScrollView>
                </MainContainer>
            </Window>
    )
}

const styles = StyleSheet.create({
    buttonShadow: {
        shadowColor: "#000",
        shadowOffset: {
            width: 1,
            height: 2,
        },
        shadowOpacity: 0.6,
        shadowRadius: 25,
        elevation: 3,
    },
    verifyButton: {
        position: 'absolute',
        alignSelf: 'center',
        right: 0,
    },
    headerBorderBottom: {
        borderBottomColor: 'rgba(0, 0, 0, 0.25)',
        borderBottomWidth: 0.2,
    }
});
