import React from "react";
import { View } from "react-native";
import { MessageProps } from "./types";
import { MessageText, MyMessage, OtherMessage } from "./style";

export const Message = ({ messageData, nickname }: MessageProps) => {

    return (
        <View>
            {
                (messageData.from === nickname) ?
                <MyMessage key={Math.random() * 1000}>
                    <MessageText messageType="my">{messageData.text}</MessageText>
                </MyMessage>
                :
                <OtherMessage key={Math.random() * 1000}>
                    <MessageText messageType="other">{messageData.text}</MessageText>
                </OtherMessage>
            }
        </View>
    );
}