import { TMessage, TMessageInternal, TMessageUser } from "../../../../../common/types/chat";

export type MessageProps = {
    messageData: TMessageUser;  // | TMessageInternal;
    nickname: string;
}