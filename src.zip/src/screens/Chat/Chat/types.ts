export type TChatChatScreenParams = undefined;

export type Theme = {
    theme: 'light' | 'dark';
} 