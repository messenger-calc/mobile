import Main from "./Main/Main";
import {ChatMessage} from "./Chat/Chat";

// TODO: спросить почему я не могу сделать import { Main } from './Main';
// И зачем нужны index.ts

export const ChatScreens = { ChatMessage, Main };
