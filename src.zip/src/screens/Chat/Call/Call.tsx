import React, { createContext, useContext, useEffect, useState } from 'react';
import PeerConnection from '../../../common/utils/PeerConnection';
import { useAppSelector } from '../../../store/hooks';
import socket from '../../../common/utils/socket';
import { ChatContext } from '../../../common/contexts/Chat/Chat';
import { REQUEST_TIMEOUT_MS } from '@env';
import { CallScreen } from './components/CallScreen/CallScreen';
import { CallingScreen } from './components/CallingScreen/CallingScreen';
import { EAppState } from '../../../store/modules/appState/slice';
import { WaitingScreen } from './components/WaitingScreen/WaitingScreen';

export type TPeerConnectionContext = {
    connection: PeerConnection;
}

export const PeerConnectionContext = createContext<TPeerConnectionContext>({
    connection: {} as PeerConnection
})

const Call = () => {
    const { setChatStatus } = useContext(ChatContext);

    const [error, setError] = useState<string>('');

    const [connection, setConnection] = useState<boolean>(false);

    const [callFrom, setCallFrom] = useState<string>('');
    const [calling, setCalling] = useState<boolean>(false);

    const [showModal, setShowModal] = useState(false);
    const [callWindow, setCallWindow] = useState(false);
    const [showCallingScreen, setShowCallingScreen] = useState<boolean>(false);
    const [showCallScreen, setShowCallScreen] = useState<boolean>(false);

    const [localSrc, setLocalSrc] = useState(null);
    const [remoteSrc, setRemoteSrc] = useState(null);

    const [pc, setPc] = useState<PeerConnection | null>(null);
    const [config, setConfig] = useState<any>({ video: false, audio: true });

    const [otherUserDeviceToken, setOtherUserDeviceToken] = useState<string>('');

    const otherUserNickname = useAppSelector(store => store.chat.otherUserNickname);
    const otherUserAppId = useAppSelector(store => store.chat.otherUserAppId);
    const appState = useAppSelector(store => store.appState.state);

    useEffect(() => {
        if (!pc) return
        console.log('Chat.jsx UseEffect #2: socket');

        socket
            .on('call', async (data) => {
                if (data.sdp) {
                    try {
                        console.log('SetRemoteDescription');
                        await pc.setRemoteDescription(data.sdp)
                    } catch (e) {
                        console.error('[ERROR]  -  ', e);
                    }


                    if (data.sdp.type === 'offer') {
                        console.log('Create offer');
                        pc.createAnswer()
                    }
                } else {
                    console.log('Create candidate');
                    await pc.addIceCandidate(data.candidate)
                }
            })
            .on('end', () => finishCall(false))
            console.log('End UseEffect #2')
    }, [pc])

    useEffect(() => {
        socket.on('voiceCallStart', (data) => {
            console.log('Start audio call fromm another peer!');
            setShowCallingScreen(true);
        })
        .on('voiceCallReject', (data) => {
            console.log('Audio Calling Rejected!')
            setChatStatus('User rejected call!');
            setTimeout(() => {
                setChatStatus('');
            }, 5000);
        })
        .on('voiceCallSuccess', (data) => {
            console.log('Start Call');
            setShowCallScreen(true);
        })
        .on('voiceCallEnd', (data) => {
            setShowCallScreen(false);
        });
    }, []);

    const startCall = (isCaller: boolean, remoteId: string) => {
        setTimeout(() => {
            if (!connection) {
                setCalling(false);
            }
        }, +REQUEST_TIMEOUT_MS)

        // const intervalId = setInterval(() => sideRequests(), 1000);
        // setSideRequestsIntervalId(intervalId);

        setError('');
        setShowModal(false)
        setCalling(true)
        setConfig(config)

        const _pc = new PeerConnection(remoteId)
            .on('localStream', (stream: any) => {
                setLocalSrc(stream)
            })
            .on('remoteStream', (stream: any) => {
                setConnection(true);
                setRemoteSrc(stream)
                setCalling(false)
            })
            .start(isCaller);
                console.log('PC Start!');
                setPc(_pc);
                setCallFrom(remoteId);

        console.log('Request timeout => ', REQUEST_TIMEOUT_MS);

    }

    const finishCall = (isCaller: boolean) => {
        console.log('[INFO] Finish Call');

        pc?.stop(isCaller)
        // stopSideRequests();
        setConnection(false)

        setPc(null)

        setCalling(false)
        setShowModal(false)

        setLocalSrc(null)
        setRemoteSrc(null)
    }

    const rejectCall = () => {
        socket.emit('end', { to: otherUserAppId })

        setShowModal(false);
    }

    const onCallingReject = () => {
        console.log('Reject!');
        setShowCallingScreen(false);
        // stopRingtone();

        console.log('From -> ', otherUserAppId);
        socket.emit('voiceCallReject', { to: otherUserAppId });
    }

    const onCallingSuccess = () => {
        startCall(false, otherUserAppId);
        socket.emit('voiceCallSuccess', { to: otherUserAppId });
        setShowCallingScreen(false);
        setShowCallScreen(true);
        // stopRingtone();
    }

    const onAudicallEnd = () => {
        setShowCallScreen(false);
        socket.emit('voiceCallEnd', { to: otherUserAppId });
    }

    useEffect(() => {
        if (appState === EAppState.SuccessAudioCall) {
            startCall(true, otherUserAppId);
        }
        if (appState === EAppState.WaitingAnswerAudioCall) {
            startCall(true, otherUserAppId);
        }
    }, [appState])

    return (
        <>
            <PeerConnectionContext.Provider value={{ connection: pc! }}>
                        {(appState === EAppState.SuccessAudioCall) && (
                                <CallScreen 
                                    peerNickname={otherUserNickname}
                                    onEndCall={onAudicallEnd}
                                    remoteSrc={remoteSrc}
                                    config={config}/>
                            )}
                        {(appState === EAppState.CallingAudioCall) && (
                            <CallingScreen 
                                peerNickname={otherUserNickname}
                                onReject={onCallingReject}
                                onSuccess={onCallingSuccess}/>
                            )}
                        {(appState === EAppState.WaitingAnswerAudioCall) && (
                            <WaitingScreen peerNickname={otherUserNickname} />
                            )}
            </PeerConnectionContext.Provider>
        </>
    );
};

export default Call;