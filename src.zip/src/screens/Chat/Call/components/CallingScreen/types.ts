export type CallingScreenProps = {
    peerNickname: string;
    onReject: () => void;
    onSuccess: () => void;
}