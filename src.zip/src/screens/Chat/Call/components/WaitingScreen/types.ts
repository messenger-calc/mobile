export type WaitingScreenProps = {
    peerNickname: string;
}