/**
 * Sample React Native Chat
 * https://github.com/facebook/react-native
 *
 * @format
 */

import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { REQUEST_TIMEOUT_MS } from "@env";
import { useNavigation } from '@react-navigation/native';
import { StyleSheet, Text, Vibration, View } from 'react-native';

import { MainWindow, CallModal, Calling } from './components';
import { useAppDispatch, useAppSelector } from '../../../store/hooks';
import { EAppState, setAppState } from '../../../store/modules/appState/slice';
import { StackNavigationProp } from '@react-navigation/stack';
import { TMainStack } from '../../../navigation/stacks/Main';
import { EStacks } from '../../../navigation/stacks/stacks';
import { EScreens } from '../../../navigation/screens';
import { clearChat } from '../../../store/modules/chat/slice';
import socket from '../../../common/utils/socket';

export default function Chat() {
    const { navigate } = useNavigation<StackNavigationProp<TMainStack>>();
    const appState = useAppSelector((store) => store.appState);
    const otherUserAppId = useAppSelector(store => store.chat.otherUserAppId);
    const appDispatch = useAppDispatch();

    const [calling, setCalling] = useState<boolean>(false);
    const [showModal, setShowModal] = useState<boolean>(false);

    useEffect(() => {
        if (appState.state === EAppState.Init) {
            console.log('Init!')
        }
        if (appState.state === EAppState.RejectConnection) {
            console.log('RejectConnection!')
            setCalling(false);
            setShowModal(false);
        }
        if (appState.state === EAppState.SuccessConnection) {
            console.log('SuccessConnection!');
            setCalling(false);
            setShowModal(false);
            navigate(EStacks.Chat, {
                screen: EScreens.ChatMessage
              });
        }
        if (appState.state === EAppState.TryConnection) {
            console.log('TryConnection!')
        }
        if (appState.state === EAppState.AskUserToConnect) {
            console.log('Ask User for connection!');
            setShowModal(true);
        }
        if (appState.state === EAppState.WaitOtherUserAnswer) {
            console.log('Wait untill other user answer!');
            setCalling(true);
        }
        if (appState.state === EAppState.FinishConnection) {
            appDispatch(clearChat());
            navigate(EStacks.Chat, {
                screen: EScreens.ChatMain
            });
        }

        if (appState.state === EAppState.ButtonStartAudioCallPressed) {
            socket.emit('voiceCallTry', { to: otherUserAppId });
            appDispatch(setAppState(EAppState.WaitingAnswerAudioCall));
            navigate(EScreens.Call);
        }
        if (appState.state === EAppState.CallingAudioCall) {
            navigate(EScreens.Call);
        }
    }, [appState]);

    const startBeep = () => {
        console.log('Start Beep!');
    }

    
    return (
        <View style={{...styles.linearGradient, backgroundColor: "#000"}}>
            <View style={styles.app}>
                <Text style={styles.appTitle}>Мессенджер</Text>
                <MainWindow/>
                {calling &&
                  <Calling startBeep={startBeep}/>}
                {showModal && <CallModal/>}
            </View>
        </View>
    )
}

const styles = StyleSheet.create({
    linearGradient: {
        flex: 1,
    },
    app: {
        flex: 1,
        color: "white",
        flexDirection: "column",
        display: "flex",
        justifyContent: 'center',
        alignItems: "center",
    },
    appTitle: {
        color: "white",
        fontSize: 35,
        position: 'absolute',
        fontWeight: "700",
        top: 50,
    },
    appError: {
        color: "#6e0b00",
        position: 'absolute',
        fontSize: 25,
        top: 100,
    },
    appButton: {
        justifyContent: 'center',
        alignItems: 'center',
        shadowColor: "#000",
        shadowOffset: {
            width: 1,
            height: 2,
        },
        shadowOpacity: 0.6,
        shadowRadius: 25,
        elevation: 3,
    },
    mainWindow: {
        position: "absolute",
        top: 0,
        right: 0,
        bottom: 0,
        left: 0,
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
    }
});
