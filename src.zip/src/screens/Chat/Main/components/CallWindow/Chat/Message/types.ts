export type MessageProps = {
    messageData: any; // TUsereMessage
    theme: string; // 'light' | 'dark'
    nickname: string;
}

export type MessageType = {
    text: string;
    from: string;
    date?: Date;
}