export type CallingProps = {
    startBeep: () => void;
}