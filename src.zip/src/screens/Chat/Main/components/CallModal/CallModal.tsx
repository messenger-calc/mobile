import {Animated, StyleSheet, View} from "react-native";
import React, {useEffect, useRef, useState} from "react";
import {ButtonIcon, ButtonIconDisable, CallModalView, Control, Inner, Title} from "./styled";
import { Svg } from "../../../../../assets/icons";
import { useAppDispatch, useAppSelector } from "../../../../../store/hooks";
import { EAppState, setAppState } from "../../../../../store/modules/appState/slice";

export const CallModal = () => {
    const scaleAnim = useRef(new Animated.Value(1)).current;
    
    let chatData = useAppSelector(store => store.chat);
    const appDispach = useAppDispatch();


    useEffect(() => {
        Animated
            .loop(
                Animated.sequence([
                    Animated.timing(scaleAnim, {
                        toValue: 1.1,
                        duration: 1000,
                        useNativeDriver: true
                    }),
                    Animated.timing(scaleAnim, {
                        toValue: 1,
                        duration: 1000,
                        useNativeDriver: true
                    })
                ])
            ).start()
    }, []);

    const connectionSuccess = () => {
        appDispach(setAppState(EAppState.SuccessConnection));
    }

    const connectionReject = () => {
        appDispach(setAppState(EAppState.RejectConnection));
    }

    return (
        <View style={styles.callModal}>
            <Animated.View style={{transform: [{scale: scaleAnim}]}}>
                <CallModalView style={styles.callModalShadow}>
                    <Inner>
                        <Title>{`${chatData.otherUserAppId} is calling`}</Title>
                        <Control>
                            <ButtonIcon onPress={connectionSuccess} style={styles.buttonShadow}>
                                <Svg.Smartphone fill={'#fff'}/>
                            </ButtonIcon>
                            <ButtonIconDisable onPress={connectionReject} style={styles.buttonShadow}>
                                <Svg.PhoneDisable fill={'#fff'}/>
                            </ButtonIconDisable>
                        </Control>
                    </Inner>
                </CallModalView>
            </Animated.View>
        </View>
    )
}

const styles = StyleSheet.create({
    callModal: {
        flex: 1,
        top: 0,
        bottom: 0,
        left: 0,
        right: 0,
        justifyContent: 'center',
        alignItems: 'center',
        position: 'absolute',
        backgroundColor: 'rgba(0, 0, 0, 0.3)'
    },
    callModalShadow: {
        shadowColor: "#000",
        shadowOffset: {
            width: 1,
            height: 2,
        },
        shadowOpacity: 0.6,
        shadowRadius: 25,
        elevation: 3,
    },
    buttonShadow: {
        shadowColor: "#000",
        shadowOffset: {
            width: 1,
            height: 2,
        },
        shadowOpacity: 0.6,
        shadowRadius: 25,
        elevation: 3,
    }
})
