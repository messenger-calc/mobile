import React, { useEffect, useRef, useState } from 'react'

import { Clipboard, LogBox, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import {
    MainWindowButtonIcon,
    MainWindowButtonText,
    MainWindowError,
    MainWindowLocalId,
    MainWindowLocalIdText,
    MainWindowRemoteId,
    MainWindowTextInput,
    MainWindowTitle,
    MainWindowView,
    RowContainer,
    ShowButton,
} from "./styled";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import { Svg } from '../../../../../assets/icons';
import { useAppDispatch, useAppSelector } from '../../../../../store/hooks';
import { EAppState, setAppState } from '../../../../../store/modules/appState/slice';
import { setOtherUserAppId } from '../../../../../store/modules/chat/slice';

export const MainWindow = () => {
    const [remoteId, setRemoteId] = useState('');
    const [localId, setLocalId] = useState<string | null>(null);
    const [localIdShow, setLocalIdShow] = useState(false);
    const [error, setError] = useState('');

    let chatData = useAppSelector(store => store.chat);
    const appDispatch = useAppDispatch();

    const call = async () => {
        if (!remoteId.trim() || remoteId.length < 5) {
            return setError('Friend id is not valid');
        }

        if (localId === remoteId) {
            return setError("You can't call to self!");
        }
        
        appDispatch(setOtherUserAppId(remoteId));
        appDispatch(setAppState(EAppState.TryConnection));
    }

    const onLocalIdPress = () => {
        setLocalIdShow(!localIdShow)
        Clipboard.setString(localId!);
    };

    return (
        <KeyboardAwareScrollView contentContainerStyle={{flex: 1, top: 200}} extraHeight={125}>
            <MainWindowView style={{flex: 1}}>
                <MainWindowLocalId>
                    <MainWindowTitle>Ваш ID</MainWindowTitle>
                    <RowContainer>
                    {
                        localIdShow
                            ? <>
                                <TouchableOpacity onPress={onLocalIdPress}>
                                    <MainWindowLocalIdText style={styles.localIdUnderline}>{chatData.userAppId}</MainWindowLocalIdText>
                                </TouchableOpacity>
                                <Text style={{color: 'white', position: 'absolute', right: 0}}>{'\u2190'} Натисніть!</Text>
                            </>
                            :
                            <ShowButton onPress={() => setLocalIdShow(!localIdShow)}>
                                <Text style={{ color: "#f1f1f1", fontSize: 18, fontWeight: "bold" }}>Показати</Text>
                            </ShowButton>
                    }
                    </RowContainer>
                </MainWindowLocalId>
                <MainWindowRemoteId>
                    <MainWindowTextInput
                        spellCheck={false}
                        autoCorrect={false}
                        placeholderTextColor={'rgba(255, 255, 255, 0.5)'}
                        placeholder='Введіть ID вашого друга'
                        maxLength={5}
                        onChangeText={(newText: string) => {
                            setError('')
                            setRemoteId(newText)
                        }}/>
                    <MainWindowError>{error}</MainWindowError>

                    <View style={styles.separator}/>

                    <View>
                        <MainWindowButtonIcon style={styles.buttonShadow} onPress={call}>
                            <Svg.Smartphone fill={'#e0e0e0'} width={30} height={30}/>
                        </MainWindowButtonIcon>
                    </View>
                </MainWindowRemoteId>
            </MainWindowView>
        </KeyboardAwareScrollView>
    )
}

const styles = StyleSheet.create({
    absolute: {
        position: "absolute",
        top: 0,
        left: 0,
        bottom: 0,
        right: 0
    },
    buttonShadow: {
        shadowColor: "#000",
        shadowOffset: {
            width: 1,
            height: 2,
        },
        shadowOpacity: 0.6,
        shadowRadius: 25,
        elevation: 3,
    },
    localIdUnderline: {
        borderStyle: 'dashed',
        borderBottomColor: '#000',
        borderBottomWidth: 1,
    },
    separator: {
        height: 1,
        width: 300,
        backgroundColor: 'rgba(0, 0, 0, 0.7)',
    },
});