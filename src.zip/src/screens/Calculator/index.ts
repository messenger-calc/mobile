import Main from "./Main/Main";

export const CalculatorScreens = { Main };