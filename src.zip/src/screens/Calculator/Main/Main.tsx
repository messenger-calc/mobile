import React from 'react';
import { Calculator } from '../../../components/Calculator/calculator';

// Calculator
const Main = () => {
    return (
        <>
            {/* <Text>Calculator Main</Text> */}
            <Calculator />
        </>
    );
};

export default Main;