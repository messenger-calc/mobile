import { NativeStackScreenProps } from "@react-navigation/native-stack";
import { TMainStack } from "../../navigation/stacks/Main";
import { NavigationProp } from "@react-navigation/native";
import { EScreens } from "../../navigation/screens";

export type ButtonProps = {
  backgroundColor: string;
  color: string;
  text: string;
  func: () => void;
  orange?: boolean;
  special?: boolean;
}

export type DisplayProps = {
  display: number
}

export type TState = {
  display: number | string;
  operation: string;
  shouldConcatenateDigit: boolean;
}

export type RootStackParamList = {
  [EScreens.CalculatorMain]: undefined;
};

export type CalculatorScreenProps = NativeStackScreenProps<TMainStack, EScreens.CalculatorMain>