import React, {Component, useEffect, useState} from 'react';
import {View, StyleSheet} from 'react-native';

import Button from './components/Button';
import Display from './components/Display';
import { CalculatorScreenProps, TState } from './types';
import { EStacks } from '../../navigation/stacks/stacks';
import { EScreens } from '../../navigation/screens';
import { useNavigation } from '@react-navigation/native';
import { TMainStack } from '../../navigation/stacks/Main';
import { StackNavigationProp } from '@react-navigation/stack';

let variableA: number;
let variableB: number;
let result: number;

export const Calculator = () => {
  const { navigate } = useNavigation<StackNavigationProp<TMainStack>>();

  const [operation, setOperation] = useState<string>('');
  const [display, setDisplay] = useState<string | number>(0);
  const [shouldConcatenateDigit, setShouldConcatenateDigit] = useState<boolean>(false);

  useEffect(() => {
    // Uncomment to instantly move to the Chat
    navigate(EStacks.Chat, {
      screen: EScreens.ChatMain
    });
  }, [])

  const concatenateDigit = (digit: string) => {
    if (shouldConcatenateDigit) {
      if (display.toString().replace(',', "").length >= 9) {

      } else if (display == "0" && digit == "0") {

      } else {
        setDisplay(prevState => Number(prevState.toString() + digit));
      }
    } else {
      setDisplay(digit);
      setShouldConcatenateDigit(true);
    }
  };

  const activateOperation = (operation: string) => {
    variableA = Number(display);
    setShouldConcatenateDigit(false);
    setOperation(operation);
  };

  const generateResult = () => {
    const startChat = (res: string | number) => {
      if (Number(res) == 4000) {
        console.log('Start Chat!');
        navigate(EStacks.Chat, {
          screen: EScreens.ChatMain
        });
      }
    }

    switch (operation) {
      case 'division':
        variableB = Number(display);
        result = variableA / variableB;
        setDisplay(+result.toFixed(5));
        setOperation('');
        break;
      case 'multiplication':
        variableB = Number(display);
        result = variableA * variableB;
        setDisplay(+result.toFixed(5));
        setOperation('');
        break;
      case 'subtraction':
        variableB = Number(display);
        result = variableA - variableB;
        setDisplay(+result.toFixed(5));
        setOperation('');
        // Start chat if res is 4000
        startChat(result);
        break;
      case 'addition':
        variableB = Number(display);
        result = variableA + variableB;
        setDisplay(+result.toFixed(5));
        setOperation('');
        // Start calculator if res is 4000
        startChat(result);
        break;
      default:
        return null;
    }
  };

  const cancelButton = () => {
    if (!shouldConcatenateDigit && display === 0) {
      setOperation('');
    }
    setDisplay(0);
    setShouldConcatenateDigit(false);
  };

  const addDot = () => {
    if (Math.round(Number(display)) === Number(display)) {
      setDisplay(prevState => `${display}.`);
      setShouldConcatenateDigit(true);
    }
  };

  const percentage = () => {
    setDisplay(prevState => Number(prevState) / 100);
  }

  const invertSignal = () => {
    setDisplay(prevState => Number(prevState) * -1);
  }

    return (
      <View style={styles.container}>
        <Display display={Number(display)}/>
        <View style={styles.row}>
          <Button
            backgroundColor="#A6A6A6"
            color="black"
            text={display ? 'C' : 'AC'}
            func={() => cancelButton()}
          />
          <Button
            backgroundColor="#A6A6A6"
            color="black"
            text="+/-"
            func={() => invertSignal()}
          />
          <Button
            backgroundColor="#A6A6A6"
            color="black"
            text="%"
            func={() => percentage()}
          />
          <Button
            orange
            backgroundColor={
              operation === 'division' ? 'white' : '#FF9404'
            }
            color={operation === 'division' ? '#FF9404' : 'white'}
            text="÷"
            func={() => activateOperation('division')}
          />
        </View>
        <View style={styles.row}>
          <Button
            backgroundColor="#333333"
            color="white"
            text="7"
            func={() => concatenateDigit("7")}
          />
          <Button
            backgroundColor="#333333"
            color="white"
            text="8"
            func={() => concatenateDigit("8")}
          />
          <Button
            backgroundColor="#333333"
            color="white"
            text="9"
            func={() => concatenateDigit("9")}
          />
          <Button
            orange
            backgroundColor={
              operation === 'multiplication' ? 'white' : '#FF9404'
            }
            color={operation === 'multiplication' ? '#FF9404' : 'white'}
            text="×"
            func={() => activateOperation('multiplication')}
          />
        </View>
        <View style={styles.row}>
          <Button
            backgroundColor="#333333"
            color="white"
            text="4"
            func={() => concatenateDigit("4")}
          />
          <Button
            backgroundColor="#333333"
            color="white"
            text="5"
            func={() => concatenateDigit("5")}
          />
          <Button
            backgroundColor="#333333"
            color="white"
            text="6"
            func={() => concatenateDigit("6")}
          />
          <Button
            orange
            backgroundColor={
              operation === 'subtraction' ? 'white' : '#FF9404'
            }
            color={operation === 'subtraction' ? '#FF9404' : 'white'}
            text='−'
            func={() => activateOperation('subtraction')}
          />
        </View>
        <View style={styles.row}>
          <Button
            backgroundColor="#333333"
            color="white"
            text="1"
            func={() => concatenateDigit("1")}
          />
          <Button
            backgroundColor="#333333"
            color="white"
            text="2"
            func={() => concatenateDigit("2")}
          />
          <Button
            backgroundColor="#333333"
            color="white"
            text="3"
            func={() => concatenateDigit("3")}
          />
          <Button
            orange
            backgroundColor={
              operation === 'addition' ? 'white' : '#FF9404'
            }
            color={operation === 'addition' ? '#FF9404' : 'white'}
            text='+'
            func={() => activateOperation('addition')}
          />
        </View>
        <View style={styles.row}>
          <Button
            special
            backgroundColor="#333333"
            color="white"
            text="0"
            func={() => concatenateDigit("0")}
          />
          <Button
            backgroundColor="#333333"
            color="white"
            text=","
            func={() => addDot()}
          />
          <Button
            orange
            backgroundColor="#FF9404"
            color="white"
            text="="
            func={() => generateResult()}
          />
        </View>
      </View>
    );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-end',
    backgroundColor: 'black',
    padding: 8,
    paddingBottom: 70,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 5,
    marginBottom: 7,
  },
  icon: {
    textAlign: 'center',
  },
});
