import Emitter from './Emitter'
import MediaDevice from './MediaDevice'
import socket from './socket'
import {RTCIceCandidate, RTCPeerConnection, RTCSessionDescription} from 'react-native-webrtc'
import { TURN_URL, TURN_USERNAME, TURN_CREDENTIALS } from "@env";
import Security from './security';
import RTCDataChannel from 'react-native-webrtc/lib/typescript/RTCDataChannel';
import { EConnection } from '../contexts/Socket/types';

const CONFIG = {
    iceServers: [
        {
            urls: "stun:stun1.l.google.com:19302",
        },
        {
            urls: "stun:stun2.l.google.com:19302",
        },
        {
            urls: TURN_URL,
            username: TURN_USERNAME,
            credential: TURN_CREDENTIALS
        },
    ]
}

class PeerConnection extends Emitter {
    remoteId: string;
    pc: RTCPeerConnection | null;
    channel: RTCDataChannel | null;
    mediaDevice: MediaDevice;

    constructor(remoteId: string) {
        super();
        this.remoteId = remoteId
        this.channel = null;

        this.pc = new RTCPeerConnection(CONFIG);
        this.pc.addEventListener('icecandidate', event => {
            socket.emit('call', {
                to: this.remoteId,
                candidate: event.candidate,
            });
        });
        this.pc.addEventListener('track', event => {
            this.emit('remoteStream', event.streams[0]);
        });
        this.mediaDevice = new MediaDevice();
        this.getDescription = this.getDescription.bind(this);
    }

    start(isCaller: boolean) {
        this.createChannel();
        this.mediaDevice
            .on('stream', (stream: any) => {
                stream.getTracks().forEach((t: any) => {
                    this.pc?.addTrack(t, stream);
                })

                this.emit('localStream', stream);

                isCaller
                    ? socket.emit('call', {to: this.remoteId })
                    : this.createOffer();
            })
            .start();

        return this;
    }

    stop(isCaller: boolean) {
        if (isCaller) {
            socket.emit('end', {to: this.remoteId})
        }

        this.mediaDevice.stop()

        try{
            this.pc?.restartIce()
            this.pc?.close();
        } catch (e) {
            console.error(e)
        }
        this.pc = null;
        return this;
    }

    createOffer() {
        console.log('Start createOffer in PeerConnection');
        this.pc?.createOffer({
            iceRestart: true,
            offerToReceiveAudio: true,
            offerToReceiveVideo: false,
          }).then(this.getDescription).catch(console.error)

          console.log('End createOffer in PeerConnection');
        return this;
    }

    createAnswer() {
        try{
            console.log('Start createAnswer in PeerConnection');
            this.pc?.createAnswer().then(this.getDescription).catch(console.error)
        } catch (e) {
            console.log(e)
        }

        console.log('End createAnswer in PeerConnection');
        return this
    }

    async getDescription(desc: RTCSessionDescription) {
        console.log('Start getDescription in PeerConnection');
        try{
            await this.pc?.setLocalDescription(desc)
    
            socket.emit('call', {to: this.remoteId, sdp: desc})
        } catch (e) {
            console.error(e);
        }

        console.log('End getDescription in PeerConnection');
        return this;
    }

    createChannel() {
        console.log('[INFO] create channel');
        try {
            this.channel = this.pc?.createDataChannel('channel') || null;
            this.channel?.addEventListener('close', event => {
                console.log('[INFO] Data channel closed');
            })
        } catch (e) {
            console.error('[ERROR Fail to create a data channel: ', e);
        }
    }

    async setRemoteDescription(desc: RTCSessionDescription) {
        try {
            console.log('Start setRemoteDescription in PeerConnection');
            await this.pc?.setRemoteDescription(new RTCSessionDescription(desc));
        } catch (e) {
            console.log(e);
        }

        console.log('End setRemoteDescription in PeerConnection');

        return this;
    }

    async addIceCandidate(candidate: RTCIceCandidate) {
        if (candidate) {
            try {
                console.log('Start addIceCandidate in PeerConnection');
                await this.pc?.addIceCandidate(new RTCIceCandidate(candidate));
            } catch (e) {
                console.log('[ERROR] ', e);
            }
        }

        console.log('End addIceCandidate in PeerConnection');

        return this;
    }
}

export default PeerConnection
