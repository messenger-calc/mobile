import { ReactNode } from "react";

export type TChildrenContext = {
    children: ReactNode,
}