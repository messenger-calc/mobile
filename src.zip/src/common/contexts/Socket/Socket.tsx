import React, { createContext, useEffect, useRef, useState } from 'react';
import { TChildrenContext } from '../types';
import { EConnection, TConnectionOffer, TSocketContext } from './types';
import { Socket } from 'socket.io-client';
import { io } from 'socket.io-client'
import { SERVER_URL } from '@env';
import { useAppDispatch, useAppSelector } from '../../../store/hooks';
import { EAppState, setAppState } from '../../../store/modules/appState/slice';
import { addMessage, setOtherUserAppId, setOtherUserNickname, setUserAppId } from '../../../store/modules/chat/slice';

export const SocketContext = createContext<TSocketContext>({
    socket: null
});

const SocketConnectionParams = {
    autoConnect: true,
    forceNew: true,
    reconnection: true,
}

const SocketContextWrapper = ({ children }: TChildrenContext) => {
    const socketRef = useRef<Socket | null>(io(SERVER_URL, SocketConnectionParams)).current;

    let appState = useAppSelector((store) => store.appState.state);
    let chatData = useAppSelector((store) => store.chat);

    const appDispatch = useAppDispatch();
    
    // const [security, setSecurity] = useState<Security | null>(null);


    useEffect(() => {
        setInterval(() => {
            socketRef?.emit('ping');
            console.log('Ping!');
        }, 120000)
    }, [])


    useEffect(() => {
        socketRef
        ?.on('init', async ({ id }) => { // Create connection to the server and get user App id
            appDispatch(setUserAppId(id));

            console.log('[INFO] Get user App id: ', id);
        }).emit('init')
        
        socketRef
        ?.on('connection', (data) => {
            if (data.type === EConnection.Offer) {
                appDispatch(setOtherUserAppId(data.from));
                appDispatch(setOtherUserNickname(data.nickname));
                
                console.log('[INFO] Someone trying to establish connection!');
                console.log('[INFO] Other user socket id: ', data.from);
                console.log('[INFO] Other user nickname: ', data.nickname);

                appDispatch(setAppState(EAppState.AskUserToConnect));
            }
            if (data.type === EConnection.Success) {
                appDispatch(setOtherUserAppId(data.from));
                appDispatch(setOtherUserNickname(data.nickname));
                
                console.log('[INFO] Connection Success!');
                console.log('[INFO] Other user socket id: ', data.from);
                console.log('[INFO] Other user nickname: ', data.nickname);

                appDispatch(setAppState(EAppState.SuccessConnection));
            }
            if (data.type === EConnection.Reject) {
                appDispatch(setAppState(EAppState.RejectConnection));
            }
        })
        .on('finishConnection', () => {
            appDispatch(setAppState(EAppState.FinishConnection));
        })
        .on('sendMessage', (message) => {
            appDispatch(addMessage(message));
        })

        socketRef?.on('voiceCallTry', (data) => {
            appDispatch(setAppState(EAppState.CallingAudioCall));
        });
    
        return () => {
          socketRef?.disconnect()
        }
    }, []);

    useEffect(() => {
        if (appState === EAppState.TryConnection) {
            console.log('[INFO] Trying to establish connection in SocketContext with data: ', { 
                type: EConnection.Offer, 
                to: chatData.otherUserAppId, 
                nickname: chatData.userNickname })
            socketRef?.emit('connection', { 
                type: EConnection.Offer, 
                to: chatData.otherUserAppId, 
                nickname: chatData.userNickname });
            appDispatch(setAppState(EAppState.WaitOtherUserAnswer));
        }
        if (appState === EAppState.SuccessConnection) {
            socketRef?.emit('connection', { 
                type: EConnection.Success, 
                to: chatData.otherUserAppId, 
                nickname: chatData.userNickname });
            appDispatch(setAppState(EAppState.SuccessConnection));
        }
        if (appState === EAppState.RejectConnection) {
            socketRef?.emit('connection', { 
                type: EConnection.Reject, 
                to: chatData.otherUserAppId, 
                nickname: chatData.userNickname });
            appDispatch(setAppState(EAppState.RejectConnection));
        }
        if (appState === EAppState.FinishConnection) {
            socketRef?.emit('finishConnection', {
                to: chatData.otherUserAppId
            })
        }
        // if (appState === EAppState.TryAudioCall) {
        //     socketRef?.emit('voiceCallTry', {
        //         to: chatData.otherUserAppId,
        //         // type: EConnection.AudioCallOffer
        //     })
        // }
    }, [appState]);
        
    //     useEffect(() => {
    //     // socket.on('encryptionPayload', (data) => {
    //     //     const bytes = crypto.AES.decrypt(data, TRANSFER_CRYPTO_PAYLOAD_KEY, { iv: TRANSFER_CRYPTO_PAYLOAD_IV });
    //     //     const payload = bytes.toString(crypto.enc.Utf8);
    //     //     security.current = new Security(payload?.secretKey, payload?.iv)
    //     socket.on('encryptionPayload', ({ secretKey, iv }) => {
    //         security.current = new Security(secretKey, iv)
    //     })
    // });

    // socket.on('request', ({ from }) => {
    //     setFrom(from)
    //     setShowModal(true);
    // })

    // socket.on('encryptionPayload', ({ secretKey, iv }) => {
    //     setSecurity(new Security(secretKey, iv));


    return (
        <SocketContext.Provider value={{
            socket: socketRef
        }}>
            {children}
        </SocketContext.Provider>
    );
};

export default SocketContextWrapper;