import { Socket } from "socket.io-client";

export enum EConnection {
    Offer = "Offer",
    Success = "Success",
    Reject = "Reject",

    AudioCallOffer = "AudioCallOffer",
    AudioCallSuccess = "AudioCallSuccess",
    AudioCallReject = "AudioCallReject",
    AudioCallPassInfo = "AudioCallPassInfo",
}

export type TConnectionOffer = {
    from: string,
    nickname: string,
    type: EConnection
}

export type TSocketContext = {
    socket: Socket | null,
    // otherUserAppId: string;
    // showModal: boolean,
    // setShowModal: (newValue: boolean) => void,
    // setOnConnectionOffer: ((data: any) => void) => void;
    // // onConnectionOffer: (data: TConnectionOffer) => void,
    // // onConnectionSuccess: (data: any) => void,
    // // onConnectionReject: (data: any) => void,
    // userAppId: string;
}