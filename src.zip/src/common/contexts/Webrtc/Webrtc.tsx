// import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
// import { TWebrtcContext } from './types';
// import { TChildrenContext } from '../types';
// import { SocketContext } from '../Socket/Socket';
// import PeerConnection from '../../utils/PeerConnection';
// import { useAppSelector } from '../../../store/hooks';
// import { EConnection } from '../Socket/types';
// import { EAppState } from '../../../store/modules/appState/slice';

// export const WebrtcContext = createContext<TWebrtcContext>({
//     localSrc: null,
//     remoteSrc: null,
// })

// export const WebrtcContextWrapper = ({ children }: TChildrenContext) => {
//     const [localSrc, setLocalSrc] = useState<any>();
//     const [remoteSrc, setRemoteSrc] = useState<any>();
//     let pcRef = useRef<PeerConnection | null>(null);

//     const { socket } = useContext(SocketContext);
//     const remoteId = useAppSelector(store => store.chat.otherUserAppId);
//     const isCaller = useAppSelector(store => store.call.isCaller);
//     const appState = useAppSelector(store => store.appState.state);

//     useEffect(() => {
//         socket
//         ?.on('call', async (data) => {
//             if (data.sdp) {
//                 try {
//                     console.log('SetRemoteDescription');
//                     await pcRef.current?.setRemoteDescription(data.sdp)
//                     } catch (e) {
//                     console.error('[ERROR]  -  ', e);
//                 }

//                 if (data.sdp.type === 'offer') {
//                     console.log('Create offer');
//                     pcRef.current?.createAnswer()
//                 }
//             } else {
//                 console.log('Create candidate');
//                 await pcRef.current?.addIceCandidate(data.candidate)
//             }
//         })
//         .on('end', () => finishCall(false))
//         console.log('End UseEffect #2')
//     }, []);


//     useEffect(() => {
//         if (appState === EAppState.TryAudioCall) {
//             startCall(isCaller);
//         }
//     }, [appState]);

//     const startCall = (isCaller: boolean) => {
//         if (!remoteId) {
//             throw Error('[Error] remoteId in null or undefined in WebrtcContext -> startCall')
//         }

//         pcRef.current = new PeerConnection(remoteId)
//             .on('localStream', (stream: any) => {
//                 setLocalSrc(stream)
//             })
//             .on('remoteStream', (stream: any) => {
//                 // setConnection(true);
//                 setRemoteSrc(stream)
//                 // setCallWindow(true);
//                 // setCalling(false)
//             })
//             .start(isCaller);
//     }

//     return (
//         <WebrtcContext.Provider value={{
//             localSrc,
//             remoteSrc,
//         }}>
//             {children}
//         </WebrtcContext.Provider>
//     );
// };