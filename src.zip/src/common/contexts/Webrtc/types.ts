export type TWebrtcContext = {
    localSrc: any,
    remoteSrc: any,
}