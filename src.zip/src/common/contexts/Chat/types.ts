import { TMessageUser, TMessageInternal } from "../../types/chat";
import Security from "../../utils/security";

export type TChatContext = {
    chat: ( TMessageUser | TMessageInternal )[];
    otherUserNickname: string;
    userNickname: string;
    security: Security | null;
    setSecurity: (value: Security | null) => void;
    theme: 'light' | 'dark';
    chatStatus: string;
    setChatStatus: (newStatus: string) => void;
    sendMessage: (message: TMessageUser | TMessageInternal) => void;
}