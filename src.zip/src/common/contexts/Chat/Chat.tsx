import React, { createContext, useEffect, useState } from 'react';
import { TChatContext } from './types';
import { TChildrenContext } from '../types';
import { EMessageType, TMessage, TMessageInternal, TMessageUser } from '../../types/chat';
import randNickname from '../../utils/randNickname';
import Security from "../../utils/security";
import { useAppDispatch, useAppSelector } from '../../../store/hooks';
import { addMessage, setUserNickname } from '../../../store/modules/chat/slice';
import { Appearance } from 'react-native';
import socket from '../../utils/socket';
import { ThemeProvider } from 'styled-components';

export const ChatContext = createContext<TChatContext>({
    chat: [],
    security: null,
    setSecurity: () => {},
    userNickname: '',
    otherUserNickname: '',
    theme: 'light',
    chatStatus: '',
    setChatStatus: () => {},
    sendMessage: () => {}
})

const ChatContextWrapper = ({ children }: TChildrenContext) => {
    const [chat, setChat] = useState<(TMessageUser | TMessageInternal)[]>([]);
    const [otherUserNickname, setOtherUserNickname] = useState<string>('');
    const [nickname, setNickname] = useState<string>(randNickname());
    const [security, setSecurity] = useState<Security | null>(null);
    const [chatStatus, setChatStatus] = useState<string>('');
    
    const [theme, setTheme] = useState<'dark' | 'light'>(Appearance.getColorScheme() || 'light');

    const appDispatch = useAppDispatch();
    let otherUserAppId = useAppSelector((store) => store.chat.otherUserAppId);


    useEffect(() => {
        Appearance.addChangeListener(({ colorScheme }) => {
            setTheme(colorScheme || 'light');
        });
    }, []);

    useEffect(() => {
        appDispatch(setUserNickname(nickname));
    }, []);

    const sendMessage = (message: TMessageUser | TMessageInternal) => {
        console.log('[INFO] MESSAGE SENDED')
        console.log('Send message payload: ', {...message, to: otherUserAppId})
        socket.emit('sendMessage', {...message, to: otherUserAppId})
        appDispatch(addMessage(message));
    }

    return (
        <ChatContext.Provider value={{
            chat,
            userNickname: nickname,
            otherUserNickname,
            security,
            setSecurity,
            theme,
            chatStatus,
            setChatStatus,
            sendMessage
        }}>
            <ThemeProvider theme={{ main: theme }} >
                {children}
            </ThemeProvider>
        </ChatContext.Provider>
    );
};

export default ChatContextWrapper;