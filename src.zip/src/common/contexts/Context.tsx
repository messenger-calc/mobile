import React, { ReactNode, useEffect, useState } from 'react';
import ChatContextWrapper from './Chat/Chat';
import SocketContextWrapper from './Socket/Socket';
import { ThemeProvider } from 'styled-components/native';
import { Appearance } from 'react-native';

type TChildren = {
    children: ReactNode,
}

const Contexts = ({ children }: TChildren) => {
    return (
        <>
            <SocketContextWrapper>
                <ChatContextWrapper>
                    {children}
                </ChatContextWrapper>
            </SocketContextWrapper>
        </>
    );
};

export default Contexts;