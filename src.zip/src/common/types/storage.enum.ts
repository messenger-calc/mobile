export enum ELocalStorage {
    OtherUserAppId = "OtherUserAppId",
    UserAppId = "UserAppId",

    UserNickname = "UserNickname",
    OtherUserNickname = "OtherUserNickname",
}