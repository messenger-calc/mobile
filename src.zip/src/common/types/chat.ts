export enum EMessageType {
    User = "User",
    Internal = "Internal",
}

export type TMessage = {
    type: EMessageType,
    show: boolean,
    date?: Date,
}

export type TMessageUser = {
    text: string,
    show: true,
    from: string,
} & TMessage;

export type TMessageInternal = {
    otherNickname: string;
    data?: any;
    show: false;
} & TMessage;